import { localeEn,Eventcalendar, localeKo,getJson, toast,setOptions, CalendarNav, Button, CalendarToday, SegmentedGroup, SegmentedItem, CalendarPrev, CalendarNext} from '@mobiscroll/react';
import React from "react";
import "@mobiscroll/react/dist/css/mobiscroll.min.css";



function Calender() {

    const [myEvents, setEvents] = React.useState([]);
    
    React.useEffect(() => {
        getJson('https://trial.mobiscroll.com/events/?vers=5', (events) => {
            setEvents(events);
        }, 'jsonp');
    }, []);
    
    const onEventClick = React.useCallback((event) => {
        toast({
            message: event.event.title
        });
    }, []);
    
    const view = React.useMemo(() => {
        return {
            calendar: { type: 'month' },
          /*  agenda: { type: 'month' }   */  
        };
    }, []);

    const myCustomHeader=()=>{
        return <>
            
            <CalendarNav />
            <CalendarPrev />
            <CalendarNext />
            <CalendarToday />
            
        </>
    }

    return (
        <Eventcalendar 
            theme="windows" 
            themeVariant="light"
            clickToCreate={false}
            dragToCreate={false}
            dragToMove={false}
            dragToResize={false}
            eventDelete={false}
            data={myEvents}
            view={view}
            onEventClick={onEventClick}
            renderHeader={myCustomHeader}
            labels={[
                {
                    start: new Date(2022, 11, 1),
                    end: new Date(2022, 11, 1),
                    text: 'ㅎㅇ',
                    color: 'red'
                },
                // {
                //     start: new Date(2022, 11, 1),
                //     end: new Date(2022, 11, 1),
                //     text: 'ㅎㅇ',
                //     color: 'green'
                // }
            ]}
            marked={[
                {
                    start:new Date(2022,11,5),
                    end:new Date(2022,11,5),
                    color:'pink'
                }
            ]}
/>
    ); 
}
export default Calender