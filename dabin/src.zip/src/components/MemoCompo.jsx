import React from "react";


const MemoCompo = () => {
  return <>memoCompo</>;
};
export default MemoCompo;
