import React from 'react'

export const MyButton = () => {
  return (
    <div>
      
      <button style={{color:undefiend}}>내가 만든 버튼!!</button>
    </div>
  )
}



