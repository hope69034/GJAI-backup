import React from 'react'
import AddEvent from '../components/AddEvent';

const AddEventPage = () => {
  return (
    <>
      <AddEvent/>
    </>
  )
}

export default AddEventPage