import Calendar from "../components/Calendar";
import AddEventButton from '../components/FreqCompo/AddEventButton';



export default () => {
  return(
    <div>
      <Calendar/>
     <AddEventButton/>  
     
    </div>
  );
}