import React from 'react'
import DoorCompo from '../components/DoorCompo';

const Door = () => {

  return (
    <>
    <DoorCompo></DoorCompo>
    </>
  )

}
export default Door;