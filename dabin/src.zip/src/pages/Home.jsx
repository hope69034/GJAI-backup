import AddEventButton from '../components/FreqCompo/AddEventButton';
import Timeline from '../components/Timeline';

/* import LabelBottomNavigation from '../components/LabelBottomNavigation'; */

export default () => {
  return(
    <>
  
     <AddEventButton/> 
      <Timeline></Timeline>
 
      </>
  );
}