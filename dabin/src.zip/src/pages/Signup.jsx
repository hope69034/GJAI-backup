import Signup from '../components/SignUp/Signup';
export default () => {
  return(
    <div>
      <Signup/>
    </div>
  );
}