import TestCompo from '../components/test/testCompo';

export default () => {
  return(
    <TestCompo/>
  );  
}