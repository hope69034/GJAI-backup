import React from 'react'
import Login from '../components/Login';
const User = () => {
  return (
    <div >
        <Login/>
    </div>
  )
}

export default User;
