import UserInfo from "../components/user/UserInfo";
export default () => {
  return(
    <>
      <UserInfo/>
    </>
  );
}